#!/bin/bash
set -e
java -Xmx4g Game 0 10 10