#!/bin/bash
set -e
java -Xmx4g Game